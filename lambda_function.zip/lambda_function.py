import json

print('Loading function')

def lambda_handler(event, context):
    return "Hello hackers at Hack4SSB!"
    #raise Exception('Something went wrong')ß